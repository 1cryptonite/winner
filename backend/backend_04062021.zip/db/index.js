const mysql = require('mysql');
const util = require('util');
const MysqlPool = mysql.createConnection({
    connectionLimit: 50000,
    host: 'localhost',
    user: 'betting',
    password: 'gbef8665b8ene894dba9',
    database: 'diamond',
    multipleStatements:true
});
MysqlPool.query = util.promisify(MysqlPool.query); // Magic happens here.
module.exports = MysqlPool;
