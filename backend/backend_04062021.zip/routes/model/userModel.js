var userdata;

exports.setUserData = function (data) {
    userdata = data;
};


exports.getUserData = function () {
    return userdata;
};
