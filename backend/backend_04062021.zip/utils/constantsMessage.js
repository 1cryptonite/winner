module.exports = Object.freeze({
	REGISTRATION_SUCCESS_MESSAGE: 'You are successfully registered.',
	UPDATED_SUCCESS_MESSAGE: 'Updated sucessfully.',
	NO_PERMISSION_MESSAGE: 'No permission to access pages.',
});
