
for (var j = 0; j < 100000; j++) {
	console.log('kkkkkkkkkkkkkkk');
}

console.log('99999999999999');
